from pathlib import Path
import json

DIRECTORY = Path(r"C:\Users\Sam\AppData\Roaming\PrismLauncher\instances\Airborn Exploration test\minecraft\resourcepacks\dye_depo_compat\assets\createdieselgenerators\textures\block\cement")

SOURCE_COLOR = "maroon"

TARGET_COLORS = [
    "rose",
    "coral",
    "indigo",
    "navy",
    "slate",
    "olive",
    "amber",
    "beige",
    "teal",
    "mint",
    "aqua",
    "verdant",
    "forest",
    "ginger",
    "tan"
]

DRY_RUN = False  # Set True to preview without writing files


def replace_in_json(value, source: str, target: str):
    """Recursively replace strings inside parsed JSON."""
    if isinstance(value, dict):
        return {
            replace_in_json(k, source, target): replace_in_json(v, source, target)
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [replace_in_json(item, source, target) for item in value]
    if isinstance(value, str):
        return value.replace(source, target)
    return value


def main():
    source_files = [
        path for path in DIRECTORY.glob("*.mcmeta")
        if SOURCE_COLOR in path.name
    ]
    print(f"Found {len(source_files)} source files to process.")

    for source_file in source_files:
        with source_file.open("r", encoding="utf-8") as f:
            data = json.load(f)

        for color in TARGET_COLORS:
            new_name = source_file.name.replace(SOURCE_COLOR, color)
            new_path = source_file.with_name(new_name)

            new_data = replace_in_json(data, SOURCE_COLOR, color)

            print(f"{source_file.name} -> {new_name}")

            if not DRY_RUN:
                with new_path.open("w", encoding="utf-8") as f:
                    json.dump(new_data, f, indent=2, ensure_ascii=False)
                    f.write("\n")


if __name__ == "__main__":
    main()